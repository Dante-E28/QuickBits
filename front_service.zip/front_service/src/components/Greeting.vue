<script setup>

</script>

<template>
    <div class="container">
        <h1>No matter where you go, everyone's connected.</h1>
    </div>
    <pre class="ascii-art">
       ____________\/____________
      /   ____________________   \
      |  /__/  \__   \__/  \__\  |
      | |    __   \__    __   \| |
      | |\__/  \__   \__/  \__ | |
      | |    __   \__    __   \| |
      | |\__/  \__   \__/  \__ | |
      | |    __   \__    __   \| |
      | |\__/  \__   \__/  \__ | |
      | |    __   \__    __   \| |
      | |\__/  \__   \__/  \__ | |
      |  \________\___________/  |
      |                 _   _    |
      |  prs           (|) (/)   |
      \_________________________/
          "--"           "--"
    </pre>
</template>

<style scoped>
.ascii-art {
  font-family: 'Courier New', Courier, monospace;
  text-align: center;
  white-space: pre;
  line-height: 1.2;
}
</style>