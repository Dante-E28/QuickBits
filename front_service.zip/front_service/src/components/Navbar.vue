<script setup>
import { useAuthStore } from '@/stores/auth.store';
import { computed } from 'vue';

const authStore = useAuthStore()

const currentUser = computed(() => {
    return authStore.userInfo
})
</script>

<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid justify-content-center">
      <div class="d-flex justify-content-center w-100 align-items-center">
        <router-link class="nav-link left-nav" to="/test">Лента</router-link>
        <router-link class="navbar-brand mx-5 logo" to="/">QuickBits</router-link>
        <router-link class="nav-link right-nav" to="/posts">Инди</router-link>
      </div>
      <div v-if="!currentUser" class="ml-auto">
        <router-link class="nav-link" to="/login">Войти</router-link>
      </div>
      <div v-else class="ml-auto">
        <router-link class="nav-link" to="/profile">{{ currentUser.username }}</router-link>
        <a class="nav-link" @click.prevent="authStore.logout">Выйти</a>
      </div>
    </div>
  </nav>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap');

.navbar {
  font-family: 'Press Start 2P', cursive;
  background-color: #f8f9fa;
  border-bottom: 2px solid #000;
}

.navbar-brand, .nav-link {
  color: #000 !important;
  font-size: 14px;
}

.navbar-brand {
  font-size: 18px;
  margin: 0;
  padding: 0;
}

.nav-link {
  margin: 0 -2px;
}

.nav-link:hover {
  color: #ad17ad !important;
  /* transform: scale(1.1); */
  /* text-shadow: 0 0 1px #000, 0 0 2px #000; */
}

.logo {
  text-align: center;
}

.d-flex {
  display: flex;
  justify-content: space-around; /* Используем space-around для уменьшения расстояния */
  align-items: center;
  width: 100%;
}

.nav-link {
  flex: 0; /* Убираем flex-grow для уменьшения расстояния */
  text-align: center;
}

.ml-auto {
  display: flex;
  align-items: center;
  gap: 30px; /* Добавляем отступ между элементами пользователя */
  position: absolute;
  right: 50px;
  margin-left: auto;
}

a {
  cursor: pointer !important;
}
</style>