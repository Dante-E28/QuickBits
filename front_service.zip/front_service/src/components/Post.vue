<script setup>
    import { ref } from 'vue';
    import { useRouter } from 'vue-router';

    const postInfo = ref(null);
    const likes = ref('Количество лайков')
    const comments = ref('Количество комментариев')
    const description = ref('Топ-менеджер Larian заявил, что «маркетинг мертв». А разработчиков Hades 2 обвинили в том, что они подставляют рынок, выпуская игру без предупреждения. Очевидно: что на высоких уровнях, что в недрах Твиттера – люди не понимают, как именно работает маркетинг. Что ж, давайте поможем им разобраться:')
    const title = ref('Заголовок')
    const author = ref({
        name: 'Автор',
        avatar: null
    })

    const router = useRouter();

    function goToPostDetail() {
      router.push('/post_detail')
    }

    function goToCreatePost() {
      router.push('/create_post')
    }
</script>

<template>
  <div class="post-container" @click="goToPostDetail">
    <div class="post-header">
      <div class="author-info">
        <p class="author-name">{{ author.name }}</p>
      </div>
      <button class="subscribe-button">Подписаться</button>
    </div>
    <h2 class="post-title">{{ title }}</h2>
    <p class="post-description">{{ description }}</p>
    <div class="post-actions">
      <span><i class="fas fa-heart"></i> {{ likes }}</span>
      <span><i class="fas fa-comment"></i> {{ comments }}</span>
    </div>
  </div>
  <div class="container post-end">
    <h1>Возможно, то, что проходит через Сеть — не просто электронная информация. Если предположить, что электрификация и телефонизация создали Сеть, то что, если в этот момент был создан новый мир?</h1>
  </div>
  <button class="floating-button" @click="goToCreatePost">Написать пост</button>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap');

.post-container {
  font-family: 'Press Start 2P', cursive;
  background-color: #f5f5f5;
  border: 2px solid #000;
  padding: 10px;
  margin-bottom: 20px;
  max-width: 800px;
  margin: 30px auto;
  text-align: left;
  cursor: pointer;
  transition: transform 0.3s;
}

/* .post-container:hover {
  transform: scale(1.05);
} */

.post-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.author-info {
  text-align: left;
}

.author-name {
  font-size: 12px;
  margin: 0;
}

.subscribe-button {
  background-color: #000;
  font-size: 10px;
  padding: 5px 7px !important;
  border: none;
  cursor: pointer;
  transition: transform 0.3s;
}

.subscribe-button:hover {
  transform: scale(1.1);
}

.post-title {
  font-size: 14px;
  margin: 10px 0;
}

.post-description {
  font-size: 12px;
  margin: 10px 0;
}

.post-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10px;
}

.post-actions i {
  margin-right: 5px;
}

.post-end h1 {
    font-size: 30px;
}

.floating-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #000;
  font-family: 'Press Start 2P', cursive;
  font-size: 14px;
  padding: 10px 20px;
  border: none;
  cursor: pointer;
  transition: transform 0.3s;
}

.floating-button:hover {
  transform: scale(1.1);
}
</style>